package com.example.onlinestorefront.services.impl;

import com.example.onlinestorefront.db.DbGood;
import com.example.onlinestorefront.db.repository.GoodsRepository;
import com.example.onlinestorefront.model.Good;
import com.example.onlinestorefront.services.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class GoodsServiceImpl implements GoodsService {

    @Autowired
    public final GoodsRepository goodsRepository;

    public GoodsServiceImpl(GoodsRepository goodsRepository) {
        this.goodsRepository = goodsRepository;
    }

    @Override
    public List<Good> getAllGoods() {
        return goodsRepository.findAll()
                .stream()
                .map(Good::of)
                .collect(Collectors.toList());
    }

    @Override
    public Good getGood(long id) {
        return goodsRepository.findById(id).map(Good::of).orElse(null);
    }

    @Override
    public void deleteById(long id) {
        goodsRepository.deleteById(id);
    }

    @Override
    public void add(Good good) {
        goodsRepository.save(good.toDbGood());
    }

    @Override
    public void edit(long id, Good good) {
        DbGood dbGood = good.toDbGood();
        dbGood.setId(id);
        goodsRepository.save(dbGood);
    }
}