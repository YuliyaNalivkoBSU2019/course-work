package com.example.onlinestorefront.services;

import com.example.onlinestorefront.model.Good;

import java.util.List;

public interface GoodsService {

    List<Good> getAllGoods();

    Good getGood(long id);

    void deleteById(long id);

    void add(Good good);

    void edit(long id, Good good);
}
