package com.example.onlinestorefront.db;


import javax.persistence.*;

@Entity
@Table(name = "goods")
public class DbGood {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;
    @Column(name = "fullName")
    private String name;
    @Column(name = "codeOfVendor")
    private String vendorCode;
    @Column(name = "goodRank")
    private String rank;
    @Column(name = "chargeMass")
    private String chargeMass;
    @Column(name = "pressure")
    private String pressure;
    @Column(name = "durationOfSupply")
    private Integer durationOfSupply;
    @Column(name = "jetLength")
    private Float jetLength;
    @Column(name = "dimensions")
    private String dimensions;
    @Column(name = "weight")
    private Float mass;
    @Column(name = "temperatureRange")
    private String temperature;
    @Column(name = "ballonDiameter")
    private Integer diameter;
    @Column(name = "fullVolume")
    private Float volume;
    @Column(name = "maxPressure")
    private String maxPressure;
    @Column(name = "rechargePeriod")
    private String recharge;
    @Column(name = "warrantyPeriod")
    private String warranty;
    @Column(name = "imgURL")
    private String imgURL;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getChargeMass() {
        return chargeMass;
    }

    public void setChargeMass(String chargeMass) {
        this.chargeMass = chargeMass;
    }

    public String getPressure() {
        return pressure;
    }

    public void setPressure(String pressure) {
        this.pressure = pressure;
    }

    public Integer getDurationOfSupply() {
        return durationOfSupply;
    }

    public void setDurationOfSupply(Integer durationOfSupply) {
        this.durationOfSupply = durationOfSupply;
    }

    public Float getJetLength() {
        return jetLength;
    }

    public void setJetLength(Float jetLength) {
        this.jetLength = jetLength;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    public Float getMass() {
        return mass;
    }

    public void setMass(Float mass) {
        this.mass = mass;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public Integer getDiameter() {
        return diameter;
    }

    public void setDiameter(Integer diameter) {
        this.diameter = diameter;
    }

    public Float getVolume() {
        return volume;
    }

    public void setVolume(Float volume) {
        this.volume = volume;
    }

    public String getMaxPressure() {
        return maxPressure;
    }

    public void setMaxPressure(String maxPressure) {
        this.maxPressure = maxPressure;
    }

    public String getRecharge() {
        return recharge;
    }

    public void setRecharge(String recharge) {
        this.recharge = recharge;
    }

    public String getWarranty() {
        return warranty;
    }

    public void setWarranty(String warranty) {
        this.warranty = warranty;
    }

    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }
}
