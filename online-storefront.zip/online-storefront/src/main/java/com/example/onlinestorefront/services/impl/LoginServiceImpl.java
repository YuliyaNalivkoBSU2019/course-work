package com.example.onlinestorefront.services.impl;

import com.example.onlinestorefront.db.DbLogin;
import com.example.onlinestorefront.db.repository.LoginRepository;
import com.example.onlinestorefront.services.LoginService;
import org.apache.commons.codec.digest.DigestUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class LoginServiceImpl implements LoginService {

    public final LoginRepository loginRepository;

    @Autowired
    public LoginServiceImpl(LoginRepository loginRepository) {
        this.loginRepository = loginRepository;
    }

    @Override
    public String login(String login, String password) {
        DbLogin dbLogin = new DbLogin();
        dbLogin.setLogin(login);

        String sha256 = DigestUtils.sha256Hex(password);
        return loginRepository.findOne(Example.of(dbLogin)).filter(loginData ->
                loginData.getPassHash().equals(sha256)
        ).map(loginData -> {
            String token = UUID.randomUUID().toString();
            loginData.setToken(token);
            loginRepository.save(loginData);
            return token;
        }).orElse(null);
    }
}
