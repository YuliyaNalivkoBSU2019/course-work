package com.example.onlinestorefront.services;

public interface LoginService {

    String login(String login, String password);
}
