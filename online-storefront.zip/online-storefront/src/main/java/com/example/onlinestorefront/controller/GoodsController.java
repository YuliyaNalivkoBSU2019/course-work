package com.example.onlinestorefront.controller;

import com.example.onlinestorefront.model.Good;
import com.example.onlinestorefront.services.GoodsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class GoodsController {

    private GoodsService goodsService;

    @Autowired
    public GoodsController(GoodsService goodsService) {
        this.goodsService = goodsService;
    }

    @GetMapping("/good/list")
    public List<Good> getAllGoods() {
        return goodsService.getAllGoods();
    }

    @GetMapping("/good/details")
    public Good getDetails(@RequestParam("id") long id) {
        return goodsService.getGood(id);
    }

    @DeleteMapping("/good")
    public void removeGood(@RequestParam("id") long id) {
        goodsService.deleteById(id);
    }

    @PostMapping("/good/add")
    public void addGood(@RequestBody Good good) {
        goodsService.add(good);
    }

    @PostMapping("/good/edit/{id}")
    public void editGood(@PathVariable("id") long id, @RequestBody Good good) {
        goodsService.edit(id, good);
    }

}
