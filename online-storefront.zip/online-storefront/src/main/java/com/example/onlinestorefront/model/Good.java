package com.example.onlinestorefront.model;

import com.example.onlinestorefront.db.DbGood;

public class Good {

    private Long id;
    private String name;
    private String vendorCode;
    private String rank;
    private String chargeMass;
    private String pressure;
    private Integer durationOfSupply;
    private Float jetLength;
    private String dimensions;
    private Float mass;
    private String temperature;
    private Integer diameter;
    private Float volume;
    private String maxPressure;
    private String recharge;
    private String warranty;
    private String imgURL;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVendorCode() {
        return vendorCode;
    }

    public void setVendorCode(String vendorCode) {
        this.vendorCode = vendorCode;
    }

    public String getRank() {
        return rank;
    }

    public void setRank(String rank) {
        this.rank = rank;
    }

    public String getChargeMass() {
        return chargeMass;
    }

    public void setChargeMass(String chargeMass) {
        this.chargeMass = chargeMass;
    }

    public String getPressure() {
        return pressure;
    }

    public void setPressure(String pressure) {
        this.pressure = pressure;
    }

    public Integer getDurationOfSupply() {
        return durationOfSupply;
    }

    public void setDurationOfSupply(Integer durationOfSupply) {
        this.durationOfSupply = durationOfSupply;
    }

    public Float getJetLength() {
        return jetLength;
    }

    public void setJetLength(Float jetLength) {
        this.jetLength = jetLength;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    public Float getMass() {
        return mass;
    }

    public void setMass(Float mass) {
        this.mass = mass;
    }

    public String getTemperature() {
        return temperature;
    }

    public void setTemperature(String temperature) {
        this.temperature = temperature;
    }

    public Integer getDiameter() {
        return diameter;
    }

    public void setDiameter(Integer diameter) {
        this.diameter = diameter;
    }

    public Float getVolume() {
        return volume;
    }

    public void setVolume(Float volume) {
        this.volume = volume;
    }

    public String getMaxPressure() {
        return maxPressure;
    }

    public void setMaxPressure(String maxPressure) {
        this.maxPressure = maxPressure;
    }

    public String getRecharge() {
        return recharge;
    }

    public void setRecharge(String recharge) {
        this.recharge = recharge;
    }

    public String getWarranty() {
        return warranty;
    }

    public void setWarranty(String warranty) {
        this.warranty = warranty;
    }

    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }

    public static Good of(DbGood dbGood) {
        Good good = new Good();
        good.setId(dbGood.getId());
        good.setName(dbGood.getName());
        good.setVendorCode(dbGood.getVendorCode());
        good.setRank(dbGood.getRank());
        good.setChargeMass(dbGood.getChargeMass());
        good.setPressure(dbGood.getPressure());
        good.setDurationOfSupply(dbGood.getDurationOfSupply());
        good.setJetLength(dbGood.getJetLength());
        good.setDimensions(dbGood.getDimensions());
        good.setMass(dbGood.getMass());
        good.setTemperature(dbGood.getTemperature());
        good.setDiameter(dbGood.getDiameter());
        good.setVolume(dbGood.getVolume());
        good.setMaxPressure(dbGood.getMaxPressure());
        good.setRecharge(dbGood.getRecharge());
        good.setWarranty(dbGood.getWarranty());
        good.setImgURL(dbGood.getImgURL());
        return good;
    }

    public DbGood toDbGood() {
        DbGood dbGood = new DbGood();
        dbGood.setName(getName());
        dbGood.setVendorCode(getVendorCode());
        dbGood.setRank(getRank());
        dbGood.setChargeMass(getChargeMass());
        dbGood.setPressure(getPressure());
        dbGood.setDurationOfSupply(getDurationOfSupply());
        dbGood.setJetLength(getJetLength());
        dbGood.setDimensions(getDimensions());
        dbGood.setMass(getMass());
        dbGood.setTemperature(getTemperature());
        dbGood.setDiameter(getDiameter());
        dbGood.setVolume(getVolume());
        dbGood.setMaxPressure(getMaxPressure());
        dbGood.setRecharge(getRecharge());
        dbGood.setWarranty(getWarranty());
        dbGood.setImgURL(getImgURL());
        return dbGood;
    }

    // это какая-то ерунда не понимаю что это удали
    /*public DbGood editDbGood(DbGood dbGood) {
        this.setId(dbGood.getId());
        this.setName(dbGood.getName());
        this.setVendorCode(dbGood.getVendorCode());
        this.setRank(dbGood.getRank());
        this.setChargeMass(dbGood.getChargeMass());
        this.setPressure(dbGood.getPressure());
        this.setDurationOfSupply(dbGood.getDurationOfSupply());
        this.setJetLength(dbGood.getJetLength());
        this.setDimensions(dbGood.getDimensions());
        this.setMass(dbGood.getMass());
        this.setTemperature(dbGood.getTemperature());
        this.setDiameter(dbGood.getDiameter());
        this.setVolume(dbGood.getVolume());
        this.setMaxPressure(dbGood.getMaxPressure());
        this.setRecharge(dbGood.getRecharge());
        this.setWarranty(dbGood.getWarranty());
        this.setImgURL(dbGood.getImgURL());
        return dbGood;
    }*/
}
