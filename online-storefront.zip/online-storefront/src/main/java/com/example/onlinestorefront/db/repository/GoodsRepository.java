package com.example.onlinestorefront.db.repository;

import com.example.onlinestorefront.db.DbGood;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GoodsRepository extends JpaRepository<DbGood, Long> {
}
