let goods;
$(function () {

    $('#searchInput').val("");

    $.get("/good/list", function( data ) {
        data.reverse();
        goods = data;
        onListLoaded(data);
    });

    $('#search').on('click', function(e) {
        let searchText = $('#searchInput').val();
        e.preventDefault();
        if (search === ""){
          return;
        }
        $('#goodsList').empty();
        $.get("/good/list", function( data ) {
            let foundGoods = [];
            for (let i = 0; i < goods.length; i++){
                let params = Object.values(goods[i]);
                for (let j = 1; j < params.length; j++){
                    if (String(params[j]).toLowerCase().includes(searchText.toLowerCase())) {
                        console.log(params[j] + ' & ' + searchText);
                       foundGoods.push(goods[i]);
                       break;
                    }
                }
            }
            onListLoaded(foundGoods);
            foundGoods=[];
        });
        return false;
    })
});

function onListLoaded(response) {
    $("#showMore").css("display", "none");
    if (response.length === 0){
        $('#goodsList').html("Ничего не найдено");
        return;
    }
    let shownGoodsCount = 0, toShow = 0, allGoodsCount = 0;

    allGoodsCount = response.length;

    toShow = (allGoodsCount < 4) ? allGoodsCount : 4;

    if (response.length > 4) {
        $("#showMore").css("display", "block");

        $('#showMore').on('click', function () {
            showMoreGoods();
            console.log(shownGoodsCount, toShow, allGoodsCount);
            document.getElementById('showMore').style.display = (shownGoodsCount === allGoodsCount) ? 'none' : 'block';
        });
    }
    showMoreGoods();

    document.getElementById('showMore').style.display = (shownGoodsCount === allGoodsCount) ? 'none' : 'block';


    function showMoreGoods() {
        for (let i = shownGoodsCount; i < toShow; i++){
            let node = createGoodNode(response[i]);
            document.getElementById('goodsList').appendChild(node);
        }
        shownGoodsCount = toShow;
        toShow = (allGoodsCount < shownGoodsCount+4) ? allGoodsCount : shownGoodsCount+4;
        console.log(shownGoodsCount, toShow);
    }

    function createGoodNode(good) {

        let item = document.createElement('a');
/*        let href = '/admin-add.html?id='+good.id;
        item.href = href;*/
        item.id = good.id;
        item.classList.add('item');

        let itemImg = document.createElement('div');
        itemImg.classList.add('item-img');
        item.appendChild(itemImg);

        let img = document.createElement('img');
        img.src = good.imgURL;
        img.title = good.name;
        img.alt = img.title;
        itemImg.appendChild(img);

        let itemInfo = document.createElement('div');
        itemInfo.classList.add('item-info');
        itemInfo.classList.add('row');
        item.appendChild(itemInfo);

        let itemName = document.createElement('div');
        itemName.classList.add('item-name');
        itemName.classList.add('col-xs-12');
        itemName.classList.add('col-sm-12');
        itemName.classList.add('col-md-6');
        itemName.classList.add('col-lg-6');
        itemInfo.appendChild(itemName);

        let goodName = document.createElement('p');
        goodName.innerText = good.name;
        itemName.appendChild(goodName);

        let itemOther = document.createElement('div');
        itemOther.classList.add('item-other');
        itemOther.classList.add('col-xs-12');
        itemOther.classList.add('col-sm-12');
        itemOther.classList.add('col-md-6');
        itemOther.classList.add('col-lg-6');
        itemInfo.appendChild(itemOther);

        let vendor = document.createElement('span');
        vendor.classList.add('item-vendor');
        vendor.innerText = good.vendorCode;
        itemOther.appendChild(vendor);

        let buttons = document.createElement('div');
        buttons.classList.add('item-btns');
        itemOther.appendChild(buttons);

        let editBtn = document.createElement('button');
        editBtn.classList.add('edit-btn');
       /* let editID = document.createAttribute('goodID');
        editID.value = good.id;
        editBtn.setAttributeNode(remID);
        editBtn.editID = good.id;*/
        buttons.appendChild(editBtn);

        let editImg = document.createElement('img');
        editImg.src = 'img/icons/edit.png';
        editImg.title = 'Редактировать';
        editImg.alt = 'Ред.';
        editBtn.appendChild(editImg);

        let removeBtn = document.createElement('button');
        removeBtn.classList.add('remove-btn');
        let remID = document.createAttribute('goodID');
        remID.value = good.id;
        removeBtn.setAttributeNode(remID);
        removeBtn.remID = good.id;
        buttons.appendChild(removeBtn);

        let removeImg = document.createElement('img');
        removeImg.classList.add('remove-img');
        removeImg.src = 'img/icons/remove.png';
        removeImg.title = 'Удалить';
        removeImg.alt = 'Удалить';
        removeBtn.appendChild(removeImg);

        return item;
    }

    $('.remove-btn').on('click', function (e) {
        e.stopPropagation();
        console.log(e.target);
        let id = e.currentTarget.getAttribute('goodId');
            $.ajax({
                url: '/good?id=' + id,
                type: 'DELETE',
                success: function(result) {
                    $('#'+id).remove();
                    /*for(let i = 0; i < response.length; i++) {
                        if(response[i].id === id){
                            response.splice(indexValueOfArray,i)
                            alert(i);
                        }
                    }*/
                }
            });
    })

    $('.item').on('click', function(e){
        e.preventDefault();
            console.log(e.target);
        if (e.currentTarget.classList.contains('remove-btn') || e.currentTarget.classList.contains('remove-img')){
            return;
        }
        window.location.assign('/admin-add.html?id='+e.currentTarget.id);
    });

}


window.addEventListener('load', function () {


});