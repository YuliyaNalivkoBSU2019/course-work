let goods = [];
$(function () {

    $.get("/good/list", function( data ) {
        goods = data;
        onListLoaded(data);
    });

$('#search').on('click', function(e) {
        let searchText = $('#searchInput').val();
        console.log(searchText);
        e.preventDefault();
        if (search === ""){
          return;
        }
        $('#catalogRow').empty();
        $.get("/good/list", function( data ) {
            let foundGoods = [];
            for (let i = 0; i < goods.length; i++){
                let params = Object.values(goods[i]);
                for (let j = 1; j < params.length; j++){
                    if (String(params[j]).toLowerCase().includes(searchText.toLowerCase())) {
                        console.log(params[j] + ' & ' + searchText);
                       foundGoods.push(goods[i]);
                       break;
                    }
                }
            }
            onListLoaded(foundGoods);
            foundGoods=[];
        });
    })
});

function onListLoaded(response) {

    let showCount = 12;
    response.reverse();

    let shownGoodsCount = 0, toShow = 0, allGoodsCount = 0;

    allGoodsCount = response.length;

    toShow = (allGoodsCount < showCount) ? allGoodsCount : showCount;

    showMoreGoods();
    document.getElementById('showMore').style.display = (shownGoodsCount === allGoodsCount) ? 'none' : 'block';

    document.getElementById('showMore').addEventListener('click', function () {
        showMoreGoods();
        document.getElementById('showMore').style.display = (shownGoodsCount === allGoodsCount) ? 'none' : 'block';
    });


    function showMoreGoods() {
        console.log(shownGoodsCount, toShow)
        for (let i = shownGoodsCount; i < toShow; i++){
            let node = createGoodNode(response[i]);
            document.getElementById('catalogRow').appendChild(node);
        }
        shownGoodsCount = toShow;

        toShow = (allGoodsCount < shownGoodsCount+showCount) ? allGoodsCount : shownGoodsCount+showCount;
    }

    function createGoodNode(good) {

        let a = document.createElement('a');
        let href = '/item.html?id='+good.id;
        a.href = href;
        console.log(href);
        a.classList.add('col-md-4');
        a.classList.add('col-lg-3');
        a.classList.add('col-6');

        let ID = document.createAttribute('ID');
        ID.value = good.id;
        a.setAttributeNode(ID);
        a.ID = good.id;

        let product = document.createElement('div');
        product.classList.add('product');
        a.appendChild(product);

        let productImg = document.createElement('div');
        productImg.classList.add('product-img');
        product.appendChild(productImg);

        let img = document.createElement('img');
        img.src = good.imgURL;
        img.title = good.name;
        img.alt = img.title;
        productImg.appendChild(img);

        let caption = document.createElement('div');
        caption.classList.add('product-caption');
        product.appendChild(caption);

        let name = document.createElement('p');
        name.classList.add('product-name');
        name.innerText = good.name;
        caption.appendChild(name);

        let volume = document.createElement('p');
        volume.classList.add('product-volume');
        volume.innerText = good.volume + " л";
        caption.appendChild(volume);

        return a;
    }

}


window.addEventListener('load', function () {

    headerBtn.addEventListener('click', function () {

        let height = document.querySelector('.main-bg').offsetHeight;
        window.scrollTo(0, height);
    });

});