window.addEventListener('load', function () {

    contactsBtn.addEventListener('click', function () {
        window.scrollTo(0, document.body.scrollHeight);
    });

});

