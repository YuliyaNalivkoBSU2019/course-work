$(function() {

    let url = new URL(window.location.href);
    let id = url.searchParams.get("id");
    console.log(id);
    $.get("/good/details?id=" + id, function( data ) {
        onDetailsLoaded(data);
    });

    $.get("/good/list", function(data) {
       fillNewList(data);
    });

    function onDetailsLoaded(item) {
        Object.keys(item).forEach(key => {
            if(key === 'imgURL'){
                $('#'+key).attr("src",item[key]);
            }
            else if(key === 'vendorCode') {
                $('#'+key).text('Артикул: '+item[key]);
            }
            else {
                $('#'+key).text(item[key]);
            }
        })
    };

    function fillNewList(goods){
        goods.reverse();
        let count =  0;
        while(count < 4 && count <= goods.length){
            if (goods[count].id !== id){
                let node = createGoodNode(goods[count++]);
                console.log(node);
                $('.new-products').append(node);
            }
        }
    }

    function createGoodNode(good) {

            let a = document.createElement('a');
            let href = '/item.html?id='+good.id;
            a.href = href;
            console.log(href);
            a.classList.add('col-md-3');
            a.classList.add('col-lg-3');
            a.classList.add('col-6');

            let ID = document.createAttribute('ID');
            ID.value = good.id;
            a.setAttributeNode(ID);
            a.ID = good.id;
            //a.href = 'item.html';

            let product = document.createElement('div');
            product.classList.add('product');
            a.appendChild(product);

            let productImg = document.createElement('div');
            productImg.classList.add('product-img');
            product.appendChild(productImg);

            let img = document.createElement('img');
            img.src = good.imgURL;
            img.title = good.name;
            img.alt = img.title;
            productImg.appendChild(img);

            let caption = document.createElement('div');
            caption.classList.add('product-caption');
            product.appendChild(caption);

            let name = document.createElement('p');
            name.classList.add('product-name');
            name.innerText = good.name;
            caption.appendChild(name);

            let volume = document.createElement('p');
            volume.classList.add('product-volume');
            volume.innerText = good.volume + " л";
            caption.appendChild(volume);

            return a;
        }


})