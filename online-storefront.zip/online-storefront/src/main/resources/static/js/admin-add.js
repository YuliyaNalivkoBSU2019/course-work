$(function () {

    let url = new URL(window.location.href);
    let id = url.searchParams.get("id");
    console.log(id);
    if (id !== null) {
        $('#header').text("Редактировать");
        $.get("/good/details?id=" + id, function (data) {
            onDetailsLoaded(data);
        });
    }

    let dataObj = {
        name: "",
        vendorCode: "",
        rank: "",
        chargeMass: "",
        pressure: "",
        durationOfSupply: "",
        jetLength: "",
        dimensions: "",
        mass: "",
        temperature: "",
        diameter: "",
        volume: "",
        maxPressure: "",
        recharge: "",
        warranty: "",
        imgURL: "/img/goods/no-photo.png"
    };

    function onDetailsLoaded(response) {
        Object.keys(response).forEach(key => {
            if (key === 'key') return;
            if (key === "imgURL") {
                dataObj.imgURL = response.imgURL;
                $('.img').css('background-image', 'url(..' + dataObj.imgURL + ')');
                $('.img').css('background-color', '#fff');
            }
            else {
                console.log($('#' + key));
                $('#' + key).val(response[key]);
            }
        });
    }

    $('#imgURL').on('change', function(e){
        let url = 'url(../img/goods/' + $('#imgURL').val().substring($('#imgURL').val().lastIndexOf('\\') + 1)+')';
        dataObj.img = url;
        alert(url);
        $('.img').css('background-image', url);
        $('.img').css('background-color', '#fff');
    })

    console.log('dataObg = ', dataObj);


    document.getElementById('durationOfSupply').addEventListener('keyup', intCheck);
    document.getElementById('diameter').addEventListener('keyup', intCheck);

    document.getElementById('jetLength').addEventListener('keyup', floatCheck);
    document.getElementById('mass').addEventListener('keyup', floatCheck);
    document.getElementById('volume').addEventListener('keyup', floatCheck);

    document.getElementById('vendorCode').addEventListener('keyup', vendorCheck);

    function floatCheck(e) {
        if (e.currentTarget.value === '.') {
            e.currentTarget.value = '0.'
        }
        e.currentTarget.value = e.currentTarget.value.replace(/[^\d.]/g, '');
    }

    function intCheck(e) {
        e.currentTarget.value = e.currentTarget.value.replace(/[^\d]/g, '');
    }

    function vendorCheck(e) {
        e.currentTarget.value = e.currentTarget.value.replace(/[^\d-]/g, '');
    }

    let error = false, isSaved = false;

    $('.save').on('click', function () {
        error = false;
        $(".required").remove();
        console.log(JSON.stringify(dataObj));
        Object.keys(dataObj).forEach(key => {
            if (key === 'key' || key === 'imgURL') return;
           /* if (key === "imgURL" && $('#imgURL').val() === "") {
                *//*if ($('#imgURL').val() === "" && response.imgURL === "") {
                    error = true;
                    let requiredText = createNote('*');
                    document.getElementById(key).parentNode.insertBefore(requiredText, document.getElementById(key))
                }
                else {*//*
                   // let url = '/img/goods/' + $('#imgURL').val().substring($('#imgURL').val().lastIndexOf('\\') + 1)
                    dataObj[key] = imgURL;
                //}
            }*/
            else {
                let value = document.getElementById(key).value;
                dataObj[key] = value.trim();

                if (value === "" && key !== 'imgURL') {
                    error = true;
                    let requiredText = createNote('Обязательное поле');
                    document.getElementById(key).parentNode.insertBefore(requiredText, document.getElementById(key))
                }
            }
        });

        console.log(error, isSaved);
        if (error === false && isSaved === false) {
            if (id === null) {
                $.ajax({
                    url: '/good/add',
                    data: JSON.stringify(dataObj),
                    contentType: 'application/json',
                    type: 'POST',
                    success: function (result) {
                        $('.save').text('Сохранено');
                        isSaved = true;
                    }
                });
            }
        }
    });
});

function createNote(text) {
    let p = document.createElement('p');
    p.classList.add('required');
    p.innerText = text;
    return p;
}

window.addEventListener('load', function () {

    window.scrollTo(0, 0);

    let previousScrollPosition = window.scrollY;

    window.addEventListener('scroll', function (e) {
        let currentScrollPosition = window.scrollY;

        if (currentScrollPosition - previousScrollPosition > 0) {
            if (currentScrollPosition > 100) {
                document.querySelector('.save').style.marginTop = '-100px';
                document.querySelector('.save').style.position = 'fixed';
            }
        }
        else {
            if (currentScrollPosition < 100) {
                document.querySelector('.save').style.marginTop = '0';
                document.querySelector('.save').style.position = 'relative';
            }
        }
        previousScrollPosition = currentScrollPosition;

    });

});