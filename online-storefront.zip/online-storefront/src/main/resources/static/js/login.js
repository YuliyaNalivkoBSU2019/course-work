$(function () {

   $('#loginBtn').on('click', function (e) {
       e.preventDefault();

       let error = false;
       console.log('p',$('#password').val());
       console.log('l',$('#login').val());

       let login = $('#login').val();
       let password = $('#password').val();
       if (login === "" ){
           error = true;
           $('#login').addClass('error');
       }
       if (password === "" ){
           error = true;
           $('#password').addClass('error');
       }
       if (error === false){
           console.log('error', error);
           window.location.replace("http://localhost:8080/admin.html");
       }

   });

});