package com.example.onlinestorefront;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineStorefrontApplicationTests {

	@Test
	void contextLoads() {
	}

}
